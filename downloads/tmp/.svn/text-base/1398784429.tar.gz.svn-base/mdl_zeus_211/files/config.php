<?php
/**
 * config.php
 *
 * @copyright Copyright (C)  ZEUS CO.,LTD.All Rights Reserved.
 * @version $Id: config.php 22307 2013-09-25 05:03:18Z shimada $
 */

require_once(MODULE_REALDIR . 'mdl_zeus_211/ZeusAdmin.php');
$objPage = new ZeusAdmin();
$objPage->init();
$objPage->process();
?>
