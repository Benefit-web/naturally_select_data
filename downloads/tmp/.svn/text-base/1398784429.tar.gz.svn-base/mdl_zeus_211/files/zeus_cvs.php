<?php
/**
 * zeus_cvs.php
 *
 * @copyright Copyright (C)  ZEUS CO.,LTD.All Rights Reserved.
 * @version $Id: zeus_cvs.php 21451 2013-06-14 05:55:54Z shimada $
 */

require_once(realpath(dirname( __FILE__)) . '/include.php');
require_once(realpath(dirname( __FILE__)) . '/ZeusCvs.php');

$objPage = new ZeusCvs();
$objPage->init();
$objPage->process();
?>
