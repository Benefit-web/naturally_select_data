<?php

/**
 * zeus_ebank_recv.php
 *
 * @copyright Copyright (C)  ZEUS CO.,LTD.All Rights Reserved.
 * @version $Id: zeus_ebank_recv.php 21452 2013-06-14 05:57:04Z shimada $
 */

require_once '../require.php';

require_once CLASS_EX_REALDIR . 'page_extends/LC_Page_Ex.php';
require_once(MODULE_REALDIR . 'mdl_zeus_211/include.php');
require_once(MODULE_REALDIR . 'mdl_zeus_211/ZeusEbankRecv.php');

$objPage = new ZeusEbankRecv();
$objPage->process();
exit;

?>